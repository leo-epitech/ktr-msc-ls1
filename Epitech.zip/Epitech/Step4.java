import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


// Ce code etait la partie onglet pour avoir la Step1 dans un onglet et la 4 dans l'autre
public class Step4 {

  public static void main(String[] args) {
    JFrame f = new JFrame("Business Card Manager");
    f.setSize(800, 350);
    JPanel pannel = new JPanel();


    JTabbedPane onglets = new JTabbedPane(SwingConstants.TOP);

    JPanel onglet1 = new JPanel();
    JLabel titreOnglet1 = new JLabel("Enter your business card information");
    onglet1.add(titreOnglet1);
    onglet1.setPreferredSize(new Dimension(700, 250));
    onglets.addTab("Profile", onglet1);


    JPanel onglet2 = new JPanel();
    JLabel titreOnglet2 = new JLabel("Library");
    onglet2.add(titreOnglet2);
    onglets.addTab("Library", onglet2);

    onglets.setOpaque(true);
    pannel.add(onglets);
    f.getContentPane().add(pannel);
    f.setVisible(true);

  }
}