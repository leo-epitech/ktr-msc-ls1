import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Setp1 extends JFrame implements ActionListener {
   JPanel panel;
   JLabel name_label, company_label, email_label, telephone_label, message;
   JTextField name_text, company_text, email_text, telephone_text;
   JButton submit, cancel;

   Setp1() {


      // Username Label
      name_label = new JLabel();
      name_label.setText("Name :");
      name_text = new JTextField();
      // Company Label
      company_label = new JLabel();
      company_label.setText("Company :");
      company_text = new JTextField();

      // Email Label
      email_label = new JLabel();
      email_label.setText("Email :");
      email_text = new JTextField();
      // Telephone Label
      telephone_label = new JLabel();
      telephone_label.setText("Telephone :");
      telephone_text = new JTextField();





      // Submit
      submit = new JButton("SAVE");
      panel = new JPanel(new GridLayout(10, 1));


      panel.add(name_label);
      panel.add(name_text);
      panel.add(company_label);
      panel.add(company_text);
      panel.add(email_label);
      panel.add(email_text);
      panel.add(telephone_label);
      panel.add(telephone_text);





      message = new JLabel();
      panel.add(message);
      panel.add(submit);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      submit.addActionListener(this);
      add(panel, BorderLayout.CENTER);
      setTitle(" Business Card Manager !");
      setSize(450,350);
      setVisible(true);
   }
   public static void main(String[] args) {
      new Setp1();
   }
   @Override
   public void actionPerformed(ActionEvent ae) {

   	  //Declaration
	  String name, company, email, telephone;

      name = name_text.getText();
      company = company_text.getText();
      email = email_text.getText();
      telephone = telephone_text.getText();
      message.setText("Saved");
     
   }
}